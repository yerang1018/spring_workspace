package p3;


import org.springframework.stereotype.Component;

@Component
public class Tire {

	
//		public class Main4 {
//			public static void main(String[] args) {
//				Car ob1 = new Car();
//				ob1.run();
//		}
	
	//	Main4 처럼 Tire 객체가 없으면 외부에서 호출해도 사용할 수 없음 
	//	외부에서 전달받아서  this.tire = tire  라는 코드가 있어야한다 
	
	
	
}
